#include <iostream>
#include <map>
#include <string>
#include <fstream>
#include <bitset>
#include <cmath>

#define DONT_CARE -1
#define BYTE_SIZE 8
#define REGISTER_FILE_SIZE 32
using namespace std;
int IfId[2],IdEx[12],ExMe[6],MeWb[5];
int registers[32];
// Register File




class RegisterFile{

private:
    int registers[REGISTER_FILE_SIZE];
public:
    RegisterFile();
    void setData(int registerNumber , int data);
    int getData(int registerNumber);
};
RegisterFile::RegisterFile() {
    fill_n(registers,REGISTER_FILE_SIZE,0);
}
void RegisterFile::setData(int registerNumber, int data) {
    this->registers[registerNumber]=data;
    return;
}
int RegisterFile::getData(int registerNumber){
    return this->registers[registerNumber];
}




// Instruction
class Instruction{
private:
    unsigned  int instruction;
public:
    Instruction(string instruction);
    void setInstruction(string instruction);
    int decodeOpCode();
    int getOpCode();
    int getInstruction();
    int indexOf(int first,int last);
};
Instruction ::Instruction(string instruction) {
    setInstruction(instruction);
}
int Instruction ::getInstruction() {
    return this->instruction;
}
int Instruction ::indexOf(int first, int last) {
    unsigned int sum =0;
    for (int i = first ; i <= last; i++){
        sum  = sum + (unsigned)pow(2,i);
    }
    return sum;
}
void Instruction ::setInstruction(string instruction) {
    this->instruction = stoi(instruction,nullptr,2);
}
int Instruction ::getOpCode() {
    return (this->instruction&this->indexOf(26,31))>>25;
}
int Instruction :: decodeOpCode(){
    int opCode = this->getOpCode();
    if(opCode==0){
        return  0;//R_Type
    }
    else if(opCode==35 || opCode ==43){
        return 1;//I_Type
    }
    else if(opCode == 2 || opCode==3){
        return 2;//J_Type
    }
    return -1;//incorrect instruction
}




//main Control Unit
class MainControlUnit{
private:
    int  ALUsrc    ;
    int  AluOp1    ;
    int  AluOp2    ;
    int  MemRead   ;
    int  MemWrite  ;
    int  RegWrite  ;
    int  MemToReg  ;
    int  RegDst    ;
    int  Branch    ;
    int  Jump      ;
public:
    MainControlUnit();
    void setSignals(Instruction instruction);
    void getSignals();
};
int MainControlUnit:: setSignals(Instruction instruction){
    map<string,int> signals;
    int opCode = instruction.getOpCode();
    int type = instruction.decodeOpCode();
    if (type==0){
       	this->ALUsrc=
       	this->AluOp1=
       	this->AluOp2=
       	this->MemRead=
       	this->MemWrite=
       	this->RegWrite=
       	this->MemToReg=
       	this->RegDst=
       	this->Branch=
       	this->Jump=
    }
    else if (type ==1 ){
        if (opCode ==35) {
            this->ALUsrc=1;
           	this->AluOp1=0;
           	this->AluOp2=0;
           	this->MemRead=1;
           	this->MemWrite=0;
           	this->RegWrite=1;
           	this->MemToReg=1;
           	this->RegDst=0;
           	this->Branch=0;
           	this->Jump=0;
        }
        else if (opCode ==43){

            signals["ALUsrc"] =1;
            signals["AluOp1"]=0;
            signals["AluOp2"]=0;
            signals["MemRead"] =0;
            signals["MemWrite"] =1;
            signals["RegWrite"] =0;
            signals["MemToReg"] =DONT_CARE;
            signals["RegDst"] =DONT_CARE;
            signals["Branch"] =0;
            signals["Jump"] =0;
        }
        else if(opCode ==4 || opCode ==5){
            signals["ALUsrc"] =0;
            signals["AluOp1"]=1;
            signals["AluOp2"]=0;
            signals["MemRead"] =0;
            signals["MemWrite"] =0;
            signals["RegWrite"] =0;
            signals["MemToReg"] =DONT_CARE;
            signals["RegDst"] =DONT_CARE;
            signals["Branch"] =0;
            signals["Jump"] =1;
        }
    }
    else if (type ==2 ){
        signals["ALUsrc"]=DONT_CARE;
        signals["AluOp1"]=DONT_CARE;
        signals["AluOp2"]=DONT_CARE;
        signals["MemRead"]=0;
        signals["MemWrite"]=0;
        signals["RegWrite"]=0;
        signals["MemToReg"]=DONT_CARE;
        signals["RegDst"] = DONT_CARE;
        signals["Branch"]=0;
        signals["Jump"]=1;
    }
    return signals;
}



//alu Control signals
int aluControl(int function , int aluOp1 ,int aluOp2){
    if(aluOp2==0 && aluOp2==0) {
        return 2;//010 addi , lw , sw
    }
    else if (aluOp2==1 && aluOp1==DONT_CARE  ){
        return 6;//110 beq , bne
    }
    else if(aluOp2==DONT_CARE  && aluOp1==0){
        if(function== 32  ){
            return 2;//010 add
        }
        else if (function ==34){
            return 6;//110 sub
        }
        else if (function==36){
            return 0;//000 and
        }
        else if (function==37){
            return 1;//001 or
        }
        else if(function==42){
            return 7;//111 slt
        }
    }
    return -1;//op code or function not correct
}



//ALU
int ALU(int opperand1 , int opperand2, int aluControlSignal){
    if (aluControlSignal==0) {
        return opperand1&opperand2;
    }
    else if(aluControlSignal==1){
        return opperand1|opperand2;
    }
    else if(aluControlSignal==2){
        return opperand1+opperand2;
    }
    else if(aluControlSignal==6){
        return  opperand1-opperand2;
    }
    else if(aluControlSignal==7){
        return opperand1<opperand2;
    }
}



//shiftLeftTwo
int shiftLeftTwo(int num ){
    return num<<2;
}



//main
int main() {
    Instruction instructions[128];
    ifstream file ("/home/sh/CLionProjects/untitled/myop.txt");
    int i = 0 ;
    if(!file.is_open()){
        cout<<"file not exist"<<endl;
        return 1;
    }
    string instruction;
    while (getline(file,instruction) && i<128){
        cout<<instruction<<endl;
        instructions->setInstruction(instruction);
        i++;
    }
    map<string,int> signals=mainControlUnit(instructions[1]);
    for (int pc = 0 ; pc<128*4;pc+2){
        if ( pc%2==0){
        }
        else if (pc%2==2){
            signals=  mainControlUnit(instructions[pc/4]);
            if(signals[])
        }
    }
    cout << "Hello, World!" << std::endl;
    string fucku = "1010";
    for (map<string,int>::iterator it=signals.begin(); it!=signals.end(); ++it) {
        cout << it->first << " => " << it->second << '\n';
    }
    return 0;
}
